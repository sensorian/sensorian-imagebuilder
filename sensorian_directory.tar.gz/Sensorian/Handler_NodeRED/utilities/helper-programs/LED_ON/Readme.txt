
Sets the logic level of the LED
