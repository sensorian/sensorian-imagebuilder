Run Flask Python app.

sudo python App.py

On the laptop side open a browser and enter the IP /port address of the Raspberry Pi.

http://IP:port/

